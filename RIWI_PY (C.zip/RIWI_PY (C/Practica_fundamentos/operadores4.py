#Escribe una fórmula que use al menos tres operadores diferentes y muestre el resultado.
a = 6
b = 5
c = 2

resultado = (a + b) * c /2
print(f"el resultado de la formula es: {resultado}")