#Solicita el nombre y edad del usuario, luego imprime un saludo personalizado que incluya ambos datos.

nombre = input("Ingrese su nombre por favor: ")
edad = int(input("ingrese su edad, por favor: "))

print(f"Bienvenido {nombre}, al club de los {edad} ")
