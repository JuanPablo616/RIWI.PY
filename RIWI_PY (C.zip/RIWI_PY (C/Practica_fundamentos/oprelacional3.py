#Escribe un programa que compare dos cadenas de texto e indique si son iguales o distintas.

cad1 = input("ingrese la primera cadena de texto: ")
cad2 = input("ingrese la segunda cadena de texto: ")

if cad1 == cad2:
    print("las cadenas son iguales!")
else:
    print("las cadenas no coinciden!")