#Calcula el área de un rectángulo a partir de base y altura ingresadas por el usuario.

base = int(input("ingrese el valor de la base del rectangulo: "))
altura = int(input("ingrese la altura del rectangulo: "))

área = base*altura

print(área)