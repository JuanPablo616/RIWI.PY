#Convierte una cadena con valor numérico a entero y realiza una suma con otro número.

num1 = 50

num2 = int(num1)

suma = num2 + 50

print(suma) 