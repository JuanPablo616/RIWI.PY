#Dado un número, determina si está en el rango de 10 a 50 (inclusive).
num = int(input("ingrese un número: "))

if num >=10 and num <= 50:
    print("el número está en el rango de 10 a 50.")
else:
    print("El numero NO está en el rango de 10 a 50.")