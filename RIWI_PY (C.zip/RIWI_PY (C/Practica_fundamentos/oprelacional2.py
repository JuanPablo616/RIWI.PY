#Solicita una edad y determina si la persona es menor de edad (menor a 18).

edad = int(input("ingrese su edad: "))

if edad >= 18:
    print("eres mayor de edad")
else:
    print("lo sentimos eres menor de edad =(")