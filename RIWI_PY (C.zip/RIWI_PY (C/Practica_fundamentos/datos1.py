#Declara una variable de cada tipo básico: entero, flotante, cadena y booleano.

entero = 10 
float = 8.0
cadena = "hola a todos"
bool = True