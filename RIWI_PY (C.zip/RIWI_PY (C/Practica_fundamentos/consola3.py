#Solicita un número y muestra su doble y su triple.

num =int(input("ingresa un numero: "))
print(num*2)
print(num*3)