#Convierte una entrada de texto a número flotante, multiplícala por 2 y muestra el resultado.

num = float(input("ingresa un numero deccimal: "))

print(num*2)