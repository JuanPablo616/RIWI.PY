#Pide al usuario que ingrese su comida favorita y su color favorito, luego imprime una frase con ambos.

Comida = input("¿Cual es tu comida favorita?: ")
color = input("¿Cuales es tu color favorito?: ")
print(f"tu comida favorita que es {Comida} y tu color favorito el {color} definen quien eres.")